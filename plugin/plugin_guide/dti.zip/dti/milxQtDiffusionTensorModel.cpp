#include "milxQtDiffusionTensorModel.h"

#include <time.h>

#include <vtkMath.h>

milxQtDiffusionTensorModel::milxQtDiffusionTensorModel(QWidget *theParent) : milxQtModel(theParent)
{
    milxQtWindow::prefix = "DTI: ";

    createActions();

    createConnections();
}

milxQtDiffusionTensorModel::~milxQtDiffusionTensorModel()
{
    //dtor
}

void milxQtDiffusionTensorModel::colourByDirection()
{

}

void milxQtDiffusionTensorModel::createActions()
{
    colourDirectionAct = new QAction(this);
        colourDirectionAct->setText(QApplication::translate("Model", "Colour By Direction", 0, QApplication::UnicodeUTF8));
        colourDirectionAct->setShortcut(tr("Alt+c"));
}

void milxQtDiffusionTensorModel::createConnections()
{
    //Operations
    connect(colourDirectionAct, SIGNAL(triggered()), this, SLOT(colourByDirection()));

    //milxQtModel::createConnections();
}

void milxQtDiffusionTensorModel::contextMenuEvent(QContextMenuEvent *currentEvent)
{
    contextMenu = milxQtModel::basicContextMenu(); //!< Only exists for the duration of the context selection

    contextMenu->addSeparator()->setText(tr("DiffusionTensor"));
    contextMenu->addAction(colourDirectionAct);
    contextMenu->addSeparator()->setText(tr("Extensions"));
    foreach(QAction *currAct, extActionsToAdd)
    {
        contextMenu->addAction(currAct);
    }
    contextMenu->addSeparator();
    ///Dont display extensions
    contextMenu->addAction(milxQtModel::scaleAct);
    contextMenu->addAction(milxQtRenderWindow::axesAct);
    contextMenu->addAction(milxQtRenderWindow::refreshAct);

    contextMenu->exec(currentEvent->globalPos());
}
