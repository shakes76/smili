#ifndef milxQtDIFFUSIONTENSORMODEL_H
#define milxQtDIFFUSIONTENSORMODEL_H

#include "milxQtModel.h"

class MILXQT_PLUGIN_EXPORT milxQtDiffusionTensorModel : public milxQtModel
{
    Q_OBJECT

public:
    milxQtDiffusionTensorModel(QWidget *theParent = 0);
    virtual ~milxQtDiffusionTensorModel();

public slots:
    void colourByDirection();

protected:
    QAction *colourDirectionAct; //!< Anisotropic Denoise action

private:
    void createActions();
    void createConnections();
    void contextMenuEvent(QContextMenuEvent *currentEvent);

};

#endif // milxQtDIFFUSIONTENSORMODEL_H
