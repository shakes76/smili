#include "milxQtDiffusionTensorPlugin.h"

#include <qplugin.h>

milxQtDiffusionTensorPlugin::milxQtDiffusionTensorPlugin(QObject *theParent) : milxQtPluginInterface(theParent)
{
    ///Up cast parent to milxQtMain
    MainWindow = qobject_cast<milxQtMain *>(theParent);

    threaded = false;
    dockable = false;
    consoleWindow = false;
    extension = true;
    pluginName = "DiffusionTensor";
    dataName = "";

    //~ createConnections();
}

milxQtDiffusionTensorPlugin::~milxQtDiffusionTensorPlugin()
{
    if(isRunning() && threaded)
        quit();
    cout << "DiffusionTensor Plugin Destroyed." << endl;
}

QString milxQtDiffusionTensorPlugin::name()
{
    return pluginName;
}

QString milxQtDiffusionTensorPlugin::openFileSupport()
{
    QString openPythonExt = "";

    return openPythonExt;
}

QStringList milxQtDiffusionTensorPlugin::openExtensions()
{
    QStringList exts;

    return exts;
}

QStringList milxQtDiffusionTensorPlugin::saveExtensions()
{
    QStringList exts;

    return exts;
}

QString milxQtDiffusionTensorPlugin::saveFileSupport()
{
    QString savePythonExt = "";

    return savePythonExt;
}

void milxQtDiffusionTensorPlugin::SetInputCollection(vtkPolyDataCollection* collection, QStringList &filenames)
{

}

void milxQtDiffusionTensorPlugin::open(QString filename)
{

}

void milxQtDiffusionTensorPlugin::save(QString filename)
{

}

milxQtRenderWindow* milxQtDiffusionTensorPlugin::genericResult()
{
    return NULL;
} //No image result

milxQtModel* milxQtDiffusionTensorPlugin::modelResult()
{
    diffusionModel = new milxQtDiffusionTensorModel;

    return diffusionModel;
} //No image result

milxQtImage* milxQtDiffusionTensorPlugin::imageResult()
{
    return NULL;
} //No image result

QDockWidget* milxQtDiffusionTensorPlugin::dockWidget()
{
    return NULL;
} //No Dock result

bool milxQtDiffusionTensorPlugin::isPluginWindow(QWidget *window)
{
    if(pluginWindow(window) == 0)
        return false;
    else
        return true;
}

milxQtDiffusionTensorModel* milxQtDiffusionTensorPlugin::pluginWindow(QWidget *window)
{
    if(window)
        return qobject_cast<milxQtDiffusionTensorModel *>(window);
    return 0;
}

void milxQtDiffusionTensorPlugin::loadExtension()
{
    if(!MainWindow->isActiveModel())
        return;

    milxQtModel *currentWin = MainWindow->activeModel();
    diffusionModel = new milxQtDiffusionTensorModel; //hierarchical deletion
        diffusionModel->setName(currentWin->getName());
        diffusionModel->SetInput(currentWin->GetOutput());
        diffusionModel->generateModel();

    MainWindow->display(diffusionModel);
}

//~ void milxQtDiffusionTensorPlugin::run()
//~ {
    //~ QMutexLocker locker(&mutex); //Lock memory

    //~ ///Execute own thread work here

    //~ //exec();
//~ }

//~ void milxQtDiffusionTensorPlugin::createConnections()
//~ {
    //~ //QObject::connect(denoiseAct, SIGNAL(triggered(bool)), denoiseModel, SLOT(denoise()));
//~ }

Q_EXPORT_PLUGIN2(DTIPlugin, milxQtDiffusionTensorPluginFactory);
